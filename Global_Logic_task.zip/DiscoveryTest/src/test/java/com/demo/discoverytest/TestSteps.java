package com.demo.discoverytest;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import com.demo.discoverytest.utility.Base;

import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;

public class TestSteps extends Base {

	Base Driverhandler;

	public TestSteps(Base Driverhandler) {
		this.Driverhandler = Driverhandler;
	}

	@Before
	public void before(Scenario s) {

		Driverhandler.initReports(s.getName());
		Driverhandler.reportLog("Reports " + s.getName());
	}

	@After
	public void after() {
		Driverhandler.quit();
		Driverhandler.reportLog("Quit browser ");
	}	

	@Then("^(.*) videos should be added and visible (.*)$")
	public void ValidateMyVideos(String expectedResult,String locatorkey) {
		Driverhandler.textvalidate(expectedResult,locatorkey);	
	}

	@Given("^I Launch (.*)$")
	public void openBrowser(String browserName) {
		Driverhandler.reportLog("Browser Launch" + browserName);
		Driverhandler.openBrowser(browserName);
	}
	
	@And("^I navigate to (.*)$")
	public void navigate(String url) {
		Driverhandler.reportLog("Go to " + url);
		Driverhandler.navigate(url);
	}

	@And("^I type (.*) in (.*) field$")
	public void type(String data, String locatorKey) {
		Driverhandler.reportLog("Typing in " + locatorKey + ". Data " + data);
		Driverhandler.type(locatorKey, data);
	}

	@And("^I clear (.*)$")
	public void clear(String locatorKey) {
		Driverhandler.reportLog("Clearing in " + locatorKey);
		Driverhandler.clear(locatorKey);
	}
	
	@And("^I hover on (.*)$")
	public void hover(String locatorKey) {
		System.out.println("----------------------"+locatorKey);
		WebElement videoEle=Driverhandler.getDriver().findElement(By.xpath(locatorKey));
		Actions act = new Actions(Driverhandler.getDriver());
		act.moveToElement(videoEle).build().perform();
		
	}


	
	@And("^I click on (.*)$")
	public void click(String locatorKey) throws InterruptedException {
		System.out.println("----------------------"+locatorKey);
		Driverhandler.reportLog("Clicking on " + locatorKey);		
		Thread.sleep(4000);
		Driverhandler.click(locatorKey);
		
	}
	
	
	@And("^I scroll to recommended(.*)$")
	public void scrollRecommended(String locatorKey) throws InterruptedException {
		
		//Thread.sleep(15000);
		Driverhandler.reportLog("Scrolling To " + locatorKey);	
		((JavascriptExecutor) Driverhandler.getDriver()).executeScript("window.scrollBy(0,3300)");
		////scroll(prop.getProperty("recommendedSection"));
	}
	
	@And("^I scroll to favouritefirstvideo(.*)$")
	public void scrollMyvideos(String locatorKey) throws InterruptedException {

		Driverhandler.reportLog("Scrolling To " + locatorKey);
		((JavascriptExecutor) Driverhandler.getDriver()).executeScript("window.scrollBy(0,500)");
		//// scroll(prop.getProperty("videoFirstTitleValidate"));
	}
	
	@And("^I navigate back to previous page$")
	public void navigateback() {
		Driverhandler.getDriver().navigate().back();
	}
	

	@And("^I click (.*) and wait for (.*)$")
	public void clickAndWait(String src, String target) {
		Driverhandler.reportLog("Clicking on " + src);
		Driverhandler.clickAndWait(src, target, 20);
	}

	@And("I select (.*) from (.*)")
	public void select(String data, String locatorKey) {
		Driverhandler.reportLog("Selecting from " + locatorKey);
		Driverhandler.select(locatorKey, data);
	}
}
