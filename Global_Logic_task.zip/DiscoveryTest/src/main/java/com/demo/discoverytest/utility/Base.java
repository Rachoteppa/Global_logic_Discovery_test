package com.demo.discoverytest.utility;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Date;
import java.util.Hashtable;
import java.util.List;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

public class Base{

	protected WebDriver driver;
	public String name;
	public Properties prop;
	public ExtentReports report;
	public ExtentTest Testscenario;
	public String LocatorKey;
	public Hashtable<String, String> data;
	public String dataKey;

	public void openBrowser(String browserName) {

			if (browserName.equals("Chrome")) {
				System.setProperty("webdriver.chrome.driver",
						System.getProperty("user.dir") + "\\chromedriver.exe");
				driver = new ChromeDriver();
			} 

		setwait();
		driver.manage().window().maximize();
		reportLog("Opened Browser");
	}
	
	public void setwait() {
		driver.manage().timeouts().implicitlyWait(90, TimeUnit.SECONDS);
		driver.manage().timeouts().pageLoadTimeout(90, TimeUnit.SECONDS);
		driver.manage().timeouts().setScriptTimeout(90, TimeUnit.SECONDS);
	}
	
	public void scroll(String yaxis) {
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", Findobjectkey(yaxis));
	}

	
	public void type(String objectKey, String data) {
		Findobjectkey(objectKey).sendKeys(data);
	}

	public void select(String objectKey, String data) {
		Select s = new Select(Findobjectkey(objectKey));
		s.selectByVisibleText(data);
	}

	public void clear(String objectKey) {
		Findobjectkey(objectKey).clear();
	}
	
	public void navigate(String urlKey) {
		driver.get(prop.getProperty(urlKey));
	}

	public void click(String objectKey) throws InterruptedException {
		Findobjectkey(objectKey).click();
	}
	
	public Base() {

		if (prop == null) {

			try {
				prop = new Properties();
				FileInputStream fs = new FileInputStream(
						System.getProperty("user.dir") + "\\src\\main\\resources\\utility.properties");
				prop.load(fs);
			} catch (Exception e) {
				e.printStackTrace();
				// report
			}
		}
	}


	
	public WebElement Findobjectkey(String objectKey) {
		WebElement e = null;
		WebDriverWait wait = new WebDriverWait(getDriver(), 10);

		try {
				e = getDriver().findElement(By.xpath(prop.getProperty(objectKey)));// present
				wait.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath(prop.getProperty(objectKey))));
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return e;
	}

	public boolean isElementInList() {
		List<WebElement> options = new Select(Findobjectkey(LocatorKey)).getOptions();
		for (int i = 0; i < options.size(); i++) {
			if (options.get(i).getText().equals(data.get(dataKey)))
				return true;
		}

		return false;
	}

	public boolean textvalidate(String text, String locatorKey) {
		try {
			boolean b = getDriver().getPageSource().contains(text);

			String Actual = driver.findElement(By.xpath(prop.getProperty(locatorKey))).getText();
			String Expected = text;
			if (b) {
				reportLog("ExpectedResult is found in the page --  "+ text);
				return true;
			} else {			
				FailureLogging("ExpectedResult is not found in the page "+"Actual-- "+Actual+"does not match with"+"Expected--"+Expected);
				return false;
			}

		} catch (Exception e) {
			return false;
		}

	}
	
	public void quit() {
		if (report != null)
			report.flush();
		if (driver != null)
			driver.quit();
	}

	public void initReports(String scenarioName) {
		String reportPath=System.getProperty("user.dir") + "\\reportFolder\\";
		report = ExtentManager.getInstance(reportPath);
		Testscenario = report.createTest(scenarioName);
		Testscenario.log(Status.INFO, "Starting " + scenarioName);
	}


	public boolean isElementPresent(String objectKey) {
		List<WebElement> e = null;

		if (objectKey.endsWith("_xpath")) {
			e = getDriver().findElements(By.xpath(prop.getProperty(objectKey)));// present
		} else if (objectKey.endsWith("_id")) {
			e = getDriver().findElements(By.id(prop.getProperty(objectKey)));// present
		} else if (objectKey.endsWith("_name")) {
			e = getDriver().findElements(By.name(prop.getProperty(objectKey)));// present
		} else if (objectKey.endsWith("_css")) {
			e = getDriver().findElements(By.cssSelector(prop.getProperty(objectKey)));// present
		}
		try {
			if (e.isEmpty())
				return false;
			else
				return true;
		} catch (java.lang.NullPointerException E) {
			return false;
		}
	}


	public void reportLog(String msg) {
		Testscenario.log(Status.PASS, msg);
	}

	public void FailureLogging(String errMsg) {
		Testscenario.log(Status.FAIL, errMsg);
		ScreenshotInvoke();
	}

	public void ScreenshotInvoke() {
		Date d = new Date();
		String screenshotFile = d.toString().replace(":", "_").replace(" ", "_") + ".png";
		File srcFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		try {
			FileUtils.copyFile(srcFile, new File(ExtentManager.screenshotFolderPath + screenshotFile));
			Testscenario.log(Status.FAIL, "Screenshot-> "
					+ Testscenario.addScreenCaptureFromPath(ExtentManager.screenshotFolderPath + screenshotFile));
		} catch (IOException e) {
			e.printStackTrace();
		}

	}
	
	public void clickAndWait(String xpathTarget, String xpathWait, int maxTime) {
		for (int i = 0; i < maxTime; i++) {
		
			Findobjectkey(xpathTarget).click();
		
			if (isElementPresent(xpathWait)
					&& getDriver().findElement(By.id(prop.getProperty(xpathWait))).isDisplayed()) {
	
				return;
			} else {

				waithelper(1);
			}

		}
		FailureLogging("Target element coming after clicking on " + xpathTarget);
	}

	public void waithelper(int time) {
		try {
			Thread.sleep(time * 1000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
	}
	
	public WebDriver getDriver() {
		return driver;
	}

	public void setDriver(WebDriver driver) {
		this.driver = driver;
	}
}
